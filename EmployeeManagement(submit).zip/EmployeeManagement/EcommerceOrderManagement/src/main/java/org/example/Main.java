package org.example;

import java.sql.*;
import java.util.Scanner;
import java.util.Set;

public class Main {

    static String url = "jdbc:mysql://localhost:3306/ecommerce_db";
    static String user = "root";
    static String password = "Nam@adv01";

    // Valid order statuses
    static final Set<String> VALID_STATUSES =
            Set.of("Pending", "Shipped", "Delivered", "Cancelled");


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try (Connection con = DriverManager.getConnection(url, user, password)) {

            System.out.println("Database Connected Successfully!");

            int choice;

            do {

                System.out.println("\n===== ORDER MANAGEMENT SYSTEM =====");

                System.out.println("1. Insert Order Records");
                System.out.println("2. Retrieve Orders by Status");
                System.out.println("3. Update Order Quantity");
                System.out.println("4. Search and Update Order Status");
                System.out.println("5. Calculate Total Order Value and Delete");
                System.out.println("0. Exit");

                System.out.print("\nEnter Your Choice: ");

                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:
                        insertOrders(con);
                        break;

                    case 2:
                        retrieveOrders(con, sc);
                        break;

                    case 3:
                        updateQuantity(con, sc);
                        break;

                    case 4:
                        updateStatus(con, sc);
                        break;

                    case 5:
                        calculateAndDelete(con, sc);
                        break;

                    case 0:
                        System.out.println("Exiting Program...");
                        break;

                    default:
                        System.out.println("Invalid Choice!");

                }

            } while (choice != 0);

        } catch (SQLException e) {

            e.printStackTrace();

        }

        sc.close();
    }


    // =====================================
    // A. INSERT THREE OR MORE ORDERS
    // =====================================

    static void insertOrders(Connection con) throws SQLException {

        String sql = "INSERT INTO `Orders` VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            int[] ids = {1001, 1002, 1003, 1004};

            String[] customers = {
                    "Rahul",
                    "Aman",
                    "Priya",
                    "Neha"
            };

            String[] products = {
                    "Laptop",
                    "Mobile",
                    "Keyboard",
                    "Monitor"
            };

            int[] quantities = {3, 5, 4, 1};

            double[] prices = {65000, 25000, 1500, 12000};

            String[] statuses = {
                    "Pending",
                    "Shipped",
                    "Delivered",
                    "Cancelled"
            };

            for (int i = 0; i < 4; i++) {

                ps.setInt(1, ids[i]);
                ps.setString(2, customers[i]);
                ps.setString(3, products[i]);
                ps.setInt(4, quantities[i]);
                ps.setDouble(5, prices[i]);
                ps.setString(6, statuses[i]);

                try {

                    ps.executeUpdate();

                    System.out.println(
                            customers[i] + " Order Inserted Successfully!"
                    );

                } catch (SQLIntegrityConstraintViolationException e) {

                    System.out.println(
                            "Duplicate Order ID: " + ids[i]
                    );

                }
            }
        }
    }


    // =====================================
    // B. RETRIEVE ORDERS BY STATUS
    // =====================================

    static void retrieveOrders(Connection con, Scanner sc)
            throws SQLException {

        System.out.print("Enter Order Status: ");

        String status = sc.nextLine();

        String sql = "SELECT * FROM `Orders` " +
                "WHERE status = ? AND quantity > 2 " +
                "ORDER BY unit_price DESC";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);

            try (ResultSet rs = ps.executeQuery()) {

                boolean found = false;

                while (rs.next()) {

                    found = true;

                    System.out.println("\nOrder ID: "
                            + rs.getInt("order_id"));

                    System.out.println("Customer: "
                            + rs.getString("customer_name"));

                    System.out.println("Product: "
                            + rs.getString("product_name"));

                    System.out.println("Quantity: "
                            + rs.getInt("quantity"));

                    System.out.println("Unit Price: "
                            + rs.getDouble("unit_price"));

                    System.out.println("Status: "
                            + rs.getString("status"));

                    System.out.println("----------------------");
                }

                if (!found) {
                    System.out.println("No Orders Found!");
                }
            }
        }
    }


    // =====================================
    // C. INCREASE EXISTING ORDER QUANTITY
    // =====================================

    static void updateQuantity(Connection con, Scanner sc)
            throws SQLException {

        System.out.print("Enter Order ID: ");

        int id = sc.nextInt();

        System.out.print("Enter Additional Quantity: ");

        int qty = sc.nextInt();

        sc.nextLine();

        if (qty <= 0) {

            System.out.println("Quantity must be greater than zero!");

            return;
        }

        String sql = "UPDATE `Orders` " +
                "SET quantity = quantity + ? " +
                "WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, qty);

            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Order Quantity Updated Successfully!");

            } else {

                System.out.println("Order Does Not Exist!");

            }
        }
    }


    // =====================================
    // D. SEARCH AND UPDATE ORDER STATUS
    // =====================================

    static void updateStatus(Connection con, Scanner sc)
            throws SQLException {

        System.out.print("Enter Order ID: ");

        int id = sc.nextInt();

        sc.nextLine();

        String search = "SELECT * FROM `Orders` WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(search)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    System.out.println("\nOrder Found!");

                    displayOrder(rs);

                } else {

                    System.out.println("Order Does Not Exist!");

                    return;
                }
            }
        }

        System.out.println("\nValid Statuses: Pending, Shipped, Delivered, Cancelled");

        System.out.print("Enter New Status: ");

        String inputStatus = sc.nextLine().trim();

        String newStatus = null;

        for (String valid : VALID_STATUSES) {

            if (valid.equalsIgnoreCase(inputStatus)) {

                newStatus = valid;

                break;
            }
        }

        if (newStatus == null) {

            System.out.println("Invalid Order Status!");

            return;
        }

        String update = "UPDATE `Orders` SET status = ? WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(update)) {

            ps.setString(1, newStatus);

            ps.setInt(2, id);

            ps.executeUpdate();

            System.out.println("\nOrder Status Updated Successfully!");
        }

        // Display Updated Order Details

        String display = "SELECT * FROM `Orders` WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(display)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    System.out.println("\nUpdated Order Details:");

                    displayOrder(rs);
                }
            }
        }
    }


    // =====================================
    // DISPLAY ORDER DETAILS
    // =====================================

    static void displayOrder(ResultSet rs) throws SQLException {

        System.out.println("Order ID: "
                + rs.getInt("order_id"));

        System.out.println("Customer: "
                + rs.getString("customer_name"));

        System.out.println("Product: "
                + rs.getString("product_name"));

        System.out.println("Quantity: "
                + rs.getInt("quantity"));

        System.out.println("Unit Price: "
                + rs.getDouble("unit_price"));

        System.out.println("Status: "
                + rs.getString("status"));
    }


    // =====================================
    // E. TOTAL ORDER VALUE AND DELETE
    // =====================================

    static void calculateAndDelete(Connection con, Scanner sc)
            throws SQLException {

        String sql = "SELECT SUM(quantity * unit_price) " +
                "AS total_order_value FROM `Orders`";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {

                double total = rs.getDouble("total_order_value");

                System.out.println("\nTotal Order Value: " + total);
            }
        }

        System.out.print("\nEnter Order ID to Delete: ");

        int id = sc.nextInt();

        sc.nextLine();

        String delete = "DELETE FROM `Orders` " +
                "WHERE order_id = ? AND status = 'Cancelled'";

        try (PreparedStatement ps = con.prepareStatement(delete)) {

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Cancelled Order Deleted Successfully!");

            } else {

                System.out.println(
                        "Order Cannot Be Deleted! " +
                                "Order does not exist or status is not Cancelled."
                );

            }
        }
    }
}