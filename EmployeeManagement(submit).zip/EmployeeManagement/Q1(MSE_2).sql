-- Create Database
CREATE DATABASE IF NOT EXISTS ecommerce_db;

-- Select Database
USE ecommerce_db;

-- Create Orders Table
CREATE TABLE IF NOT EXISTS `Orders` (

    order_id INT PRIMARY KEY,

    customer_name VARCHAR(100),

    product_name VARCHAR(100),

    quantity INT,

    unit_price DOUBLE,

    status VARCHAR(30)

);

-- Check Table Structure
DESC `Orders`;

-- Display Records
SELECT * FROM `Orders`;