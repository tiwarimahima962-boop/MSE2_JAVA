package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.Book;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/books")
public class BookController {

    ArrayList<Book> books = new ArrayList<>();

    // 1. Add Book
    @PostMapping
    public String addBook(@RequestBody Book book) {

        for (Book b : books) {
            if (b.getId() == book.getId()) {
                return "Book ID already exists!";
            }
        }

        books.add(book);
        return "Book Added Successfully!";
    }

    // 2. Get All Books
    @GetMapping
    public ArrayList<Book> getAllBooks() {
        return books;
    }

    // 3. Get Book By ID
    @GetMapping("/{id}")
    public Book getBookById(@PathVariable int id) {

        for (Book b : books) {
            if (b.getId() == id) {
                return b;
            }
        }

        return null;
    }

    // 4. Update Book
    @PutMapping("/{id}")
    public String updateBook(@PathVariable int id,
                             @RequestBody Book updatedBook) {

        for (Book b : books) {
            if (b.getId() == id) {

                b.setTitle(updatedBook.getTitle());
                b.setAuthor(updatedBook.getAuthor());
                b.setCategory(updatedBook.getCategory());
                b.setAvailableCopies(updatedBook.getAvailableCopies());

                return "Book Updated Successfully!";
            }
        }

        return "Book Not Found!";
    }

    // 5. Delete Book
    @DeleteMapping("/{id}")
    public String deleteBook(@PathVariable int id) {

        Iterator<Book> iterator = books.iterator();

        while (iterator.hasNext()) {
            Book b = iterator.next();

            if (b.getId() == id) {
                iterator.remove();
                return "Book Deleted Successfully!";
            }
        }

        return "Book Not Found!";
    }
}